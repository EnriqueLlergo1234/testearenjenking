package testcase;

public class Multiple_test_suites
{
    /**
     * Se puede ejecutar varios test suites a la vez, mastersuise.xml, para ello tenemos que utilizar
     * suite.files
     */
}
