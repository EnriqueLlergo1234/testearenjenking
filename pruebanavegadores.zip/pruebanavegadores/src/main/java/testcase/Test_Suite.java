package testcase;

public class Test_Suite
{
    /**
     * - Puedes crear varios textng.xml pero con el nombre cambiado
     * - Se utiliza para ejecutar varios test a la vez
     * - El name de los test no puede ser el mismo
     * - El codigo se copia tal cual
     */
}
